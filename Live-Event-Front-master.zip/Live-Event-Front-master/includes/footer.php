<footer>
    <div >
        <!-- Nom de la compagnie -->
        <p class="le_footer">Live Events</p>
    </div>
    <div>
        <!-- Liens vers les réseaux sociaux -->
        <a href="https://twitter.com/votrecompte" target="_blank"><i class="fab fa-twitter">&nbsp;Twitter</i></a>
        <a href="https://www.instagram.com/votrecompte" target="_blank"><i class="fab fa-instagram">&nbsp;Instagram</i></a>
        <a href="https://www.facebook.com/votrepage" target="_blank"><i class="fab fa-facebook">&nbsp;Facebook</i></a>
    </div>
    <div>
        <!-- Mentions légales -->
        <p class="le_footer">Mentions légales</p>
    </div>
</footer>
</body>