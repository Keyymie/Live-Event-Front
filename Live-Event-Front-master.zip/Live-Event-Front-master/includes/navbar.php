<header>
<h1>Live Events 2024</h1>
<p>Une expérience inoubliable de musique, de culture et de plaisir !</p>
</header>
<nav>
        <a href="/wordpress/wp-admin/live-events/index.php">Accueil</a>
        <a href="/wordpress/wp-admin/live-events/src/events.php">Programme</a>
        <a href="/wordpress/wp-admin/live-events/src/concert.php">Concerts</a>
        <a href="http://localhost/wordpress/wp-admin/live-events/src/partner.php">Partenaires</a>
        <a href="/wordpress/wp-admin/live-events/src/faq.php">FAQ</a>
        <!-- <img src="/wordpress/wp-admin/live-events/assets/img/menu-btn.png" alt="menu en burger" class="menu-burger"> -->
        <script src="/wordpress/wp-admin/live-events/src/js/mobile-menu.js"></script>
    </nav>

<main>